CREATE DATABASE HOTELS_2019v1 
GO

USE HOTELS_2019v1
GO
 
CREATE TABLE hotels(
     hotel_id int primary key not null
    ,hotel_name varchar(30) not null
    ,hotel_country_id int not null
	,hotel_city_id int not null
    ,hotel_address varchar(50) not null
    ,hotel_stars int not null
    ,hotel_telephone varchar(20) not null
    ,hotel_email varchar(50) not null
    ,hotel_www varchar(50) not null
	)
	
CREATE TABLE rooms(
     room_id int primary key not null
    ,room_hotel_id int not null
    ,room_number int not null
    ,room_floor int not null
    ,room_people int not null
	) 

ALTER TABLE rooms
	ADD CONSTRAINT fk_rooms_hotels FOREIGN KEY (room_hotel_id) REFERENCES hotels(hotel_id) 	
	 
 CREATE TABLE reservations(
     reservation_id bigint primary key not null
    ,reservation_client_id int not null
    ,reservation_starting_date date not null
    ,reservation_final_date date not null
    ,reservation_room_id int not null
    ,reservation_parking_id int    
    ,reservation_realized bit not null
	)

ALTER TABLE reservations
	ADD CONSTRAINT fk_reservations_rooms FOREIGN KEY (reservation_room_id) REFERENCES rooms(room_id) 	 
 
 CREATE TABLE clients(
     client_id int primary key not null
    ,client_first_name varchar(20) not null
    ,client_last_name varchar(40) not null
    ,client_country_id int not null
    ,client_city_id int not null
    ,client_address varchar(50) not null
    ,client_counter int    not null
    ,client_document_number varchar(40) not null 
    )
ALTER TABLE reservations
	ADD CONSTRAINT fk_reservations_clients FOREIGN KEY (reservation_client_id) REFERENCES clients(client_id) 

CREATE TABLE countries(
         country_id int primary key not null
        ,country_name varchar(50) not null
        ,country_code varchar(3) not null
		) 
CREATE TABLE cities(
         city_id int primary key not null
        ,city_name varchar(50) not null
        ,city_code varchar(20) not null
		) 	

ALTER TABLE hotels
    ADD CONSTRAINT fk_hotels_cities FOREIGN KEY (hotel_city_id) REFERENCES cities(city_id) 

ALTER TABLE clients
    ADD CONSTRAINT fk_clients_cities FOREIGN KEY (client_city_id) REFERENCES cities(city_id)     			
    
ALTER TABLE hotels
	ADD CONSTRAINT fk_hotels_countries FOREIGN KEY (hotel_country_id) REFERENCES countries(country_id) 

ALTER TABLE clients
	ADD CONSTRAINT fk_clients_countries FOREIGN KEY (client_country_id) REFERENCES countries(country_id) 

CREATE TABLE parking(
     parking_id int primary key not null
    ,parking_hotel_id int not null
    ,parking_number int not null
	)

ALTER TABLE reservations
	ADD CONSTRAINT fk_reservations_parking FOREIGN KEY (reservation_parking_id) REFERENCES parking(parking_id) 
	

INSERT INTO countries VALUES(1,'Polska','PL');	
INSERT INTO countries VALUES(2,'Irandia','IE');
INSERT INTO countries VALUES(3,'Anglia','GB');
INSERT INTO countries VALUES(4,'Czechy','CZ');
INSERT INTO countries VALUES(5,'Słowacja','SK');
INSERT INTO countries VALUES(6,'Niemcy','DE');
INSERT INTO countries VALUES(7,'Francja','FR');

INSERT INTO cities VALUES(1,'Warszawa','02-495');-- Warszawa (Ursus)	
INSERT INTO cities VALUES(2,'Kraków','31-144');
INSERT INTO cities VALUES(3,'Katowice','');
INSERT INTO cities VALUES(4,'Poznań','');
INSERT INTO cities VALUES(5,'Gdańsk','');
INSERT INTO cities VALUES(6,'Rzeszów','');
INSERT INTO cities VALUES(7,'Dublin','');
INSERT INTO cities VALUES(8,'Londyn','');
INSERT INTO cities VALUES(9,'Praga','');
INSERT INTO cities VALUES(10,'Bratysława','');
INSERT INTO cities VALUES(11,'Berlin','');
INSERT INTO cities VALUES(12,'Paryż','');
						
INSERT INTO hotels VALUES(1,'Dwoobok',1,1,'Ul.Zielona 11',2,'+48 22 5896 57 49','Dwoobok@przyklad.pl','www.Dwoobok.twoja_domena.pl');
INSERT INTO hotels VALUES(2,'Tri-hotel',1,1,'Ul.Zielna 14',3,'+48 22 138 16 84','Tri-hotel@przyklad.pl','www.Tri-hotel.twoja_domena.pl');
INSERT INTO hotels VALUES(3,'Czworak',1,1,'Ul.Barwna 67',4,'+48 22 158 64 78','Czworak@przyklad.pl','www.Czworak.twoja_domena.pl');
INSERT INTO hotels VALUES(4,'Piêtaszek',1,1,'Ul.Jutra 1',5,'+48 22 364 12 21','Piêtaszek@przyklad.pl','www.Piêtaszek.twoja_domena.pl');
INSERT INTO hotels VALUES(5,'Sześcian',1,1,'Ul.Sześcienna 42',4,'+48 22 137 98 65','Sześcian@przyklad.pl','www.Sześcian.twoja_domena.pl');
      
INSERT INTO hotels VALUES(6,'Sioodemka',1,2,'Ul.Jaśminowa 12',3,'+48 12 987 65 32','Sioodemka@przyklad.pl','www.Sioodemka.twoja_domena.pl');
INSERT INTO hotels VALUES(7,'O-Ratio',1,2,'Ul.Dêbowa 33',2,'+48 12 654 32 45','O-Ratio@przyklad.pl','www.O-Ratio.twoja_domena.pl');
INSERT INTO hotels VALUES(8,'Nine-levels',1,2,'Ul.Klonowa 7',3,'+48 12 546 12 78','Nine-levels@przyklad.pl','www.Nine-levels.twoja_domena.pl');
INSERT INTO hotels VALUES(9,'B-Ten',1,2,'Ul.Bukowa 43',4,'+48 12 753 45 45','B-Ten@przyklad.pl','www.B-Ten.twoja_domena.pl');
      
INSERT INTO hotels VALUES(10,'O-Eleven',1,3,'Ul.Brzozowa 2',5,'+48 32 123 45 45','O-Eleven@przyklad.pl','www.O-Eleven.twoja_domena.pl');
INSERT INTO hotels VALUES(11,'Twelwe',1,3,'Ul.Czeremchowa 218',4,'+48 32 654 87 54','Twelwe@przyklad.pl','www.Twelwe.twoja_domena.pl');
INSERT INTO hotels VALUES(12,'TTN',1,3,'Ul.Jabłoni 23',3,'+48 32 841 84 14','TTN@przyklad.pl','www.TTN.twoja_domena.pl');
-- Poznań 4       
INSERT INTO hotels VALUES(13,'F-T-Hotels',1,4,'Ul.Jesionowa 63',2,'+48 61 985 65 89','F-T-Hotels@przyklad.pl','www.F-T-Hotels.twoja_domena.pl');
INSERT INTO hotels VALUES(14,'Memo',1,4,'Ul.Olchowa 83',3,'+48 61 658 96 58','Memo@przyklad.pl','www.Memo.twoja_domena.pl');
INSERT INTO hotels VALUES(15,'Liil',1,4,'Ul.Głogowa 35',4,'+48 61 225 44 66','Liil@przyklad.pl','www.Liil.twoja_domena.pl');
INSERT INTO hotels VALUES(16,'Paf',1,4,'Ul.Ul.Zielna 11 63',2,'+48 61 5896 57 49','Paf@przyklad.pl','www.Paf.twoja_domena.pl');
-- Gdańsk 4       
INSERT INTO hotels VALUES(17,'Tio',1,5,'Ul.Piaskowa 6',3,'+48 58 138 16 84','Tio@przyklad.pl','www.Tio.twoja_domena.pl');
INSERT INTO hotels VALUES(18,'Arrci',1,5,'Ul.Pystynna 4',4,'+48 58 158 64 78','Arrci@przyklad.pl','www.Arrci.twoja_domena.pl');
INSERT INTO hotels VALUES(19,'Ryzat',1,5,'Ul.Rzeczna 66',5,'+48 58 364 12 21','Ryzat@przyklad.pl','www.Ryzat.twoja_domena.pl');
INSERT INTO hotels VALUES(20,'Zia',1,5,'Ul.Hotelowa 5',4,'+48 58 137 98 65','Zia@przyklad.pl','www.Zia.twoja_domena.pl');
-- Rzeszów 2       
INSERT INTO hotels VALUES(21,'Velu',1,6,'Ul.Jasna 2',3,'+48 17 987 65 32','Velu@przyklad.pl','www.Velu.twoja_domena.pl');
INSERT INTO hotels VALUES(22,'Vea',1,6,'Ul.Biała 89',2,'+48 17 654 32 45','Vea@przyklad.pl','www.Vea.twoja_domena.pl');
-- Zagranica       
-- Dublin 2       
INSERT INTO hotels VALUES(23,'Gakof',2,7,'White street 15',3,'+353 546 12 78','Gakof@przyklad.pl','www.Gakof.twoja_domena.pl');
INSERT INTO hotels VALUES(24,'Hady',2,7,'Orange street 69',4,'+353 753 45 45','Hady@przyklad.pl','www.Hady.twoja_domena.pl');
-- Londyn 3       
INSERT INTO hotels VALUES(25,'Bel',3,8,'St John St 5',5,'+44 171 123 45 45','Bel@przyklad.pl','www.Bel.twoja_domena.pl');
INSERT INTO hotels VALUES(26,'Hifu',3,8,'Elia St 1',4,'+44 171 654 87 54','Hifu@przyklad.pl','www.Hifu.twoja_domena.pl');
INSERT INTO hotels VALUES(27,'Zumder',3,8,'New St 7',3,'+44 171 841 84 14','Zumder@przyklad.pl','www.Zumder.twoja_domena.pl');
-- Praga 3       
INSERT INTO hotels VALUES(28,'Bumgi',4,9,'Kreslicka 5',3,'+420 658 96 58','Bumgi@przyklad.pl','www.Bumgi.twoja_domena.pl');
INSERT INTO hotels VALUES(29,'Cus',4,9,'Kozacka 5',2,'+420 985 65 89','Cus@przyklad.pl','www.Cus.twoja_domena.pl');
INSERT INTO hotels VALUES(30,'Bumgi',4,9,'Krynmska 5',3,'+420 658 96 58','Bumgi@przyklad.pl','www.Bumgi.twoja_domena.pl');
-- Bratysława 10       
INSERT INTO hotels VALUES(31,'Cus',5,10,'Medena 5',2,'+421 7  985 65 89','Cus@przyklad.pl','www.Cus.twoja_domena.pl');
INSERT INTO hotels VALUES(32,'Lagi',5,10,'Dunajska 8',3,'+421 7  591 65 74','Lagi@przyklad.pl','www.Lagi.twoja_domena.pl');
-- Berlin 11       
INSERT INTO hotels VALUES(33,'Lumi',6,11,'Kopenicker Str.3',4,'+49 123846084','Lumi@przyklad.pl','www.Lumi.twoja_domena.pl');
INSERT INTO hotels VALUES(34,'Mikka',6,11,'Berlin Str.74',5,'+49 761954845','Mikka@przyklad.pl','www.Mikka.twoja_domena.pl');
INSERT INTO hotels VALUES(35,'Leo',6,11,'Noger Str.37',4,'+49 761845954','Leo@przyklad.pl','www.Leo.twoja_domena.pl');
-- Paryż 12       
INSERT INTO hotels VALUES(36,'Lungari',7,12,'Rue de Rivoli 55',3,'+32 985 89 65','Lungari@przyklad.pl','www.Lungari.twoja_domena.pl');
INSERT INTO hotels VALUES(37,'Lambe',7,12,'Avenue Victoria 3',2,'+32 965 32 87','Lambe@przyklad.pl','www.Lambe.twoja_domena.pl');
INSERT INTO hotels VALUES(38,'Pirue',7,12,'Rue Pernelle 46',3,'+32 652 45 43','Pirue@przyklad.pl','www.Pirue.twoja_domena.pl');

-- rooms
INSERT INTO rooms VALUES(1,1,1,1,1);
INSERT INTO rooms VALUES(2,1,2,2,2);
INSERT INTO rooms VALUES(3,1,3,3,3);
INSERT INTO rooms VALUES(4,1,4,4,4);
INSERT INTO rooms VALUES(5,1,5,5,5);
INSERT INTO rooms VALUES(6,2,11,1,2);
INSERT INTO rooms VALUES(7,2,22,2,3);
INSERT INTO rooms VALUES(8,2,33,3,4);
INSERT INTO rooms VALUES(9,2,44,4,5);
INSERT INTO rooms VALUES(10,2,55,5,2);
INSERT INTO rooms VALUES(11,3,1,1,1);
INSERT INTO rooms VALUES(12,3,2,1,1);
INSERT INTO rooms VALUES(13,3,3,2,2);
INSERT INTO rooms VALUES(14,3,4,2,2);
INSERT INTO rooms VALUES(15,3,5,3,3);
INSERT INTO rooms VALUES(16,4,12,2,2);
INSERT INTO rooms VALUES(17,4,23,2,3);
INSERT INTO rooms VALUES(18,4,34,2,2);
INSERT INTO rooms VALUES(19,4,45,2,3);
INSERT INTO rooms VALUES(20,4,56,2,2);
INSERT INTO rooms VALUES(21,5,1,2,2);
INSERT INTO rooms VALUES(22,5,2,2,2);
INSERT INTO rooms VALUES(23,5,3,3,3);
INSERT INTO rooms VALUES(24,5,4,3,3);
INSERT INTO rooms VALUES(25,5,5,4,4);
INSERT INTO rooms VALUES(26,6,1,1,1);
INSERT INTO rooms VALUES(27,6,2,2,2);
INSERT INTO rooms VALUES(28,6,3,3,3);
INSERT INTO rooms VALUES(29,6,4,4,4);
INSERT INTO rooms VALUES(30,6,5,5,5);
INSERT INTO rooms VALUES(31,7,11,1,2);
INSERT INTO rooms VALUES(32,7,22,2,3);
INSERT INTO rooms VALUES(33,7,33,3,4);
INSERT INTO rooms VALUES(34,7,44,4,5);
INSERT INTO rooms VALUES(35,7,55,5,2);
INSERT INTO rooms VALUES(36,8,1,1,1);
INSERT INTO rooms VALUES(37,8,2,1,1);
INSERT INTO rooms VALUES(38,8,3,2,2);
INSERT INTO rooms VALUES(39,8,4,2,2);
INSERT INTO rooms VALUES(40,8,5,3,3);
INSERT INTO rooms VALUES(41,9,12,2,2);
INSERT INTO rooms VALUES(42,9,23,2,3);
INSERT INTO rooms VALUES(43,9,34,2,2);
INSERT INTO rooms VALUES(44,9,45,2,3);
INSERT INTO rooms VALUES(45,9,56,2,2);
INSERT INTO rooms VALUES(46,10,1,2,2);
INSERT INTO rooms VALUES(47,10,2,2,2);
INSERT INTO rooms VALUES(48,10,3,3,3);
INSERT INTO rooms VALUES(49,10,4,3,3);
INSERT INTO rooms VALUES(50,10,5,4,4);
INSERT INTO rooms VALUES(51,11,1,1,1);
INSERT INTO rooms VALUES(52,11,2,2,2);
INSERT INTO rooms VALUES(53,11,3,3,3);
INSERT INTO rooms VALUES(54,11,4,4,4);
INSERT INTO rooms VALUES(55,11,5,5,5);
INSERT INTO rooms VALUES(56,12,11,1,2);
INSERT INTO rooms VALUES(57,12,22,2,3);
INSERT INTO rooms VALUES(58,12,33,3,4);
INSERT INTO rooms VALUES(59,12,44,4,5);
INSERT INTO rooms VALUES(60,12,55,5,2);
INSERT INTO rooms VALUES(61,13,1,1,1);
INSERT INTO rooms VALUES(62,13,2,1,1);
INSERT INTO rooms VALUES(63,13,3,2,2);
INSERT INTO rooms VALUES(64,13,4,2,2);
INSERT INTO rooms VALUES(65,13,5,3,3);
INSERT INTO rooms VALUES(66,14,12,2,2);
INSERT INTO rooms VALUES(67,14,23,2,3);
INSERT INTO rooms VALUES(68,14,34,2,2);
INSERT INTO rooms VALUES(69,14,45,2,3);
INSERT INTO rooms VALUES(70,14,56,2,2);
INSERT INTO rooms VALUES(71,15,1,2,2);
INSERT INTO rooms VALUES(72,15,2,2,2);
INSERT INTO rooms VALUES(73,15,3,3,3);
INSERT INTO rooms VALUES(74,15,4,3,3);
INSERT INTO rooms VALUES(75,15,5,4,4);
INSERT INTO rooms VALUES(76,16,1,1,1);
INSERT INTO rooms VALUES(77,16,2,2,2);
INSERT INTO rooms VALUES(78,16,3,3,3);
INSERT INTO rooms VALUES(79,16,4,4,4);
INSERT INTO rooms VALUES(80,16,5,5,5);
INSERT INTO rooms VALUES(81,17,11,1,2);
INSERT INTO rooms VALUES(82,17,22,2,3);
INSERT INTO rooms VALUES(83,17,33,3,4);
INSERT INTO rooms VALUES(84,17,44,4,5);
INSERT INTO rooms VALUES(85,17,55,5,2);
INSERT INTO rooms VALUES(86,18,1,1,1);
INSERT INTO rooms VALUES(87,18,2,1,1);
INSERT INTO rooms VALUES(88,18,3,2,2);
INSERT INTO rooms VALUES(89,18,4,2,2);
INSERT INTO rooms VALUES(90,18,5,3,3);
INSERT INTO rooms VALUES(91,19,12,2,2);
INSERT INTO rooms VALUES(92,19,23,2,3);
INSERT INTO rooms VALUES(93,19,34,2,2);
INSERT INTO rooms VALUES(94,19,45,2,3);
INSERT INTO rooms VALUES(95,19,56,2,2);
INSERT INTO rooms VALUES(96,20,1,2,2);
INSERT INTO rooms VALUES(97,20,2,2,2);
INSERT INTO rooms VALUES(98,20,3,3,3);
INSERT INTO rooms VALUES(99,20,4,3,3);
INSERT INTO rooms VALUES(100,20,5,4,4);
INSERT INTO rooms VALUES(101,21,1,1,1);
INSERT INTO rooms VALUES(102,21,2,2,2);
INSERT INTO rooms VALUES(103,21,3,3,3);
INSERT INTO rooms VALUES(104,21,4,4,4);
INSERT INTO rooms VALUES(105,21,5,5,5);
INSERT INTO rooms VALUES(106,22,11,1,2);
INSERT INTO rooms VALUES(107,22,22,2,3);
INSERT INTO rooms VALUES(108,22,33,3,4);
INSERT INTO rooms VALUES(109,22,44,4,5);
INSERT INTO rooms VALUES(110,22,55,5,2);
INSERT INTO rooms VALUES(111,23,1,1,1);
INSERT INTO rooms VALUES(112,23,2,1,1);
INSERT INTO rooms VALUES(113,23,3,2,2);
INSERT INTO rooms VALUES(114,23,4,2,2);
INSERT INTO rooms VALUES(115,23,5,3,3);
INSERT INTO rooms VALUES(116,24,12,2,2);
INSERT INTO rooms VALUES(117,24,23,2,3);
INSERT INTO rooms VALUES(118,24,34,2,2);
INSERT INTO rooms VALUES(119,24,45,2,3);
INSERT INTO rooms VALUES(120,24,56,2,2);
INSERT INTO rooms VALUES(121,25,1,2,2);
INSERT INTO rooms VALUES(122,25,2,2,2);
INSERT INTO rooms VALUES(123,25,3,3,3);
INSERT INTO rooms VALUES(124,25,4,3,3);
INSERT INTO rooms VALUES(125,25,5,4,4);
INSERT INTO rooms VALUES(126,26,1,1,1);
INSERT INTO rooms VALUES(127,26,2,2,2);
INSERT INTO rooms VALUES(128,26,3,3,3);
INSERT INTO rooms VALUES(129,26,4,4,4);
INSERT INTO rooms VALUES(130,26,5,5,5);
INSERT INTO rooms VALUES(131,27,11,1,2);
INSERT INTO rooms VALUES(132,27,22,2,3);
INSERT INTO rooms VALUES(133,27,33,3,4);
INSERT INTO rooms VALUES(134,27,44,4,5);
INSERT INTO rooms VALUES(135,27,55,5,2);
INSERT INTO rooms VALUES(136,28,1,1,1);
INSERT INTO rooms VALUES(137,28,2,1,1);
INSERT INTO rooms VALUES(138,28,3,2,2);
INSERT INTO rooms VALUES(139,28,4,2,2);
INSERT INTO rooms VALUES(140,28,5,3,3);
INSERT INTO rooms VALUES(141,29,12,2,2);
INSERT INTO rooms VALUES(142,29,23,2,3);
INSERT INTO rooms VALUES(143,29,34,2,2);
INSERT INTO rooms VALUES(144,29,45,2,3);
INSERT INTO rooms VALUES(145,29,56,2,2);
INSERT INTO rooms VALUES(146,30,1,2,2);
INSERT INTO rooms VALUES(147,30,2,2,2);
INSERT INTO rooms VALUES(148,30,3,3,3);
INSERT INTO rooms VALUES(149,30,4,3,3);
INSERT INTO rooms VALUES(150,30,5,4,4);
INSERT INTO rooms VALUES(151,31,1,1,1);
INSERT INTO rooms VALUES(152,31,2,2,2);
INSERT INTO rooms VALUES(153,31,3,3,3);
INSERT INTO rooms VALUES(154,31,4,4,4);
INSERT INTO rooms VALUES(155,31,5,5,5);
INSERT INTO rooms VALUES(156,32,11,1,2);
INSERT INTO rooms VALUES(157,32,22,2,3);
INSERT INTO rooms VALUES(158,32,33,3,4);
INSERT INTO rooms VALUES(159,32,44,4,5);
INSERT INTO rooms VALUES(160,32,55,5,2);
INSERT INTO rooms VALUES(161,33,1,1,1);
INSERT INTO rooms VALUES(162,33,2,1,1);
INSERT INTO rooms VALUES(163,33,3,2,2);
INSERT INTO rooms VALUES(164,33,4,2,2);
INSERT INTO rooms VALUES(165,33,5,3,3);
INSERT INTO rooms VALUES(166,34,12,2,2);
INSERT INTO rooms VALUES(167,34,23,2,3);
INSERT INTO rooms VALUES(168,34,34,2,2);
INSERT INTO rooms VALUES(169,34,45,2,3);
INSERT INTO rooms VALUES(170,34,56,2,2);
INSERT INTO rooms VALUES(171,35,1,2,2);
INSERT INTO rooms VALUES(172,35,2,2,2);
INSERT INTO rooms VALUES(173,35,3,3,3);
INSERT INTO rooms VALUES(174,35,4,3,3);
INSERT INTO rooms VALUES(175,35,5,4,4);
INSERT INTO rooms VALUES(176,36,1,1,1);
INSERT INTO rooms VALUES(177,36,2,2,2);
INSERT INTO rooms VALUES(178,36,3,3,3);
INSERT INTO rooms VALUES(179,36,4,4,4);
INSERT INTO rooms VALUES(180,36,5,5,5);
INSERT INTO rooms VALUES(181,37,11,1,2);
INSERT INTO rooms VALUES(182,37,22,2,3);
INSERT INTO rooms VALUES(183,37,33,3,4);
INSERT INTO rooms VALUES(184,37,44,4,5);
INSERT INTO rooms VALUES(185,37,55,5,2);
INSERT INTO rooms VALUES(186,38,1,1,1);
INSERT INTO rooms VALUES(187,38,2,1,1);
INSERT INTO rooms VALUES(188,38,3,2,2);
INSERT INTO rooms VALUES(189,38,4,2,2);
INSERT INTO rooms VALUES(190,38,5,3,3);

-- parking
INSERT INTO parking VALUES(1,1,1);
INSERT INTO parking VALUES(2,1,2);
INSERT INTO parking VALUES(3,1,3);
INSERT INTO parking VALUES(4,1,4);
INSERT INTO parking VALUES(5,1,5);
INSERT INTO parking VALUES(6,1,6);
INSERT INTO parking VALUES(7,1,7);
INSERT INTO parking VALUES(8,1,8);
INSERT INTO parking VALUES(9,1,9);
INSERT INTO parking VALUES(10,1,10);
INSERT INTO parking VALUES(11,3,1);
INSERT INTO parking VALUES(12,3,2);
INSERT INTO parking VALUES(13,3,3);
INSERT INTO parking VALUES(14,3,4);
INSERT INTO parking VALUES(15,3,5);
INSERT INTO parking VALUES(16,4,1);
INSERT INTO parking VALUES(17,4,2);
INSERT INTO parking VALUES(18,4,3);
INSERT INTO parking VALUES(19,4,4);
INSERT INTO parking VALUES(20,4,5);
INSERT INTO parking VALUES(21,5,1);
INSERT INTO parking VALUES(22,5,2);
INSERT INTO parking VALUES(23,5,3);
INSERT INTO parking VALUES(24,5,4);
INSERT INTO parking VALUES(25,5,5);
INSERT INTO parking VALUES(26,6,1);
INSERT INTO parking VALUES(27,6,2);
INSERT INTO parking VALUES(28,6,3);
INSERT INTO parking VALUES(29,6,4);
INSERT INTO parking VALUES(30,6,5);
INSERT INTO parking VALUES(31,7,1);
INSERT INTO parking VALUES(32,7,2);
INSERT INTO parking VALUES(33,7,3);
INSERT INTO parking VALUES(34,7,4);
INSERT INTO parking VALUES(35,7,5);
INSERT INTO parking VALUES(36,7,6);
INSERT INTO parking VALUES(37,7,7);
INSERT INTO parking VALUES(38,9,1);
INSERT INTO parking VALUES(39,9,2);
INSERT INTO parking VALUES(40,9,3);
INSERT INTO parking VALUES(41,9,4);
INSERT INTO parking VALUES(42,9,5);
INSERT INTO parking VALUES(43,9,6);
INSERT INTO parking VALUES(44,9,7);
INSERT INTO parking VALUES(45,9,8);
INSERT INTO parking VALUES(46,10,1);
INSERT INTO parking VALUES(47,10,2);
INSERT INTO parking VALUES(48,10,3);
INSERT INTO parking VALUES(49,10,4);
INSERT INTO parking VALUES(50,10,5);
INSERT INTO parking VALUES(51,11,1);
INSERT INTO parking VALUES(52,11,2);
INSERT INTO parking VALUES(53,11,3);
INSERT INTO parking VALUES(54,11,4);
INSERT INTO parking VALUES(55,11,5);
INSERT INTO parking VALUES(56,12,1);
INSERT INTO parking VALUES(57,12,2);
INSERT INTO parking VALUES(58,12,3);
INSERT INTO parking VALUES(59,12,4);
INSERT INTO parking VALUES(60,12,5);
INSERT INTO parking VALUES(61,12,6);
INSERT INTO parking VALUES(62,12,7);
INSERT INTO parking VALUES(63,12,8);
INSERT INTO parking VALUES(64,12,9);
INSERT INTO parking VALUES(65,14,1);
INSERT INTO parking VALUES(66,14,2);
INSERT INTO parking VALUES(67,14,3);
INSERT INTO parking VALUES(68,14,4);
INSERT INTO parking VALUES(69,14,5);
INSERT INTO parking VALUES(70,14,6);
INSERT INTO parking VALUES(71,15,1);
INSERT INTO parking VALUES(72,15,2);
INSERT INTO parking VALUES(73,15,3);
INSERT INTO parking VALUES(74,15,4);
INSERT INTO parking VALUES(75,15,5);
INSERT INTO parking VALUES(76,16,1);
INSERT INTO parking VALUES(77,16,2);
INSERT INTO parking VALUES(78,16,3);
INSERT INTO parking VALUES(79,16,4);
INSERT INTO parking VALUES(80,16,5);
INSERT INTO parking VALUES(81,16,6);
INSERT INTO parking VALUES(82,16,7);
INSERT INTO parking VALUES(83,16,8);
INSERT INTO parking VALUES(84,16,9);
INSERT INTO parking VALUES(85,16,10);
INSERT INTO parking VALUES(86,18,1);
INSERT INTO parking VALUES(87,18,2);
INSERT INTO parking VALUES(88,18,3);
INSERT INTO parking VALUES(89,18,4);
INSERT INTO parking VALUES(90,18,5);
INSERT INTO parking VALUES(91,19,1);
INSERT INTO parking VALUES(92,19,2);
INSERT INTO parking VALUES(93,19,3);
INSERT INTO parking VALUES(94,19,4);
INSERT INTO parking VALUES(95,19,5);
INSERT INTO parking VALUES(96,20,1);
INSERT INTO parking VALUES(97,20,2);
INSERT INTO parking VALUES(98,20,3);
INSERT INTO parking VALUES(99,20,4);
INSERT INTO parking VALUES(100,20,5);
INSERT INTO parking VALUES(101,21,1);
INSERT INTO parking VALUES(102,21,2);
INSERT INTO parking VALUES(103,21,3);
INSERT INTO parking VALUES(104,21,4);
INSERT INTO parking VALUES(105,21,5);
INSERT INTO parking VALUES(106,21,6);
INSERT INTO parking VALUES(107,22,1);
INSERT INTO parking VALUES(108,22,2);
INSERT INTO parking VALUES(109,22,3);
INSERT INTO parking VALUES(110,22,4);
INSERT INTO parking VALUES(111,23,1);
INSERT INTO parking VALUES(112,23,2);
INSERT INTO parking VALUES(113,23,3);
INSERT INTO parking VALUES(114,23,4);
INSERT INTO parking VALUES(115,23,5);
INSERT INTO parking VALUES(116,24,1);
INSERT INTO parking VALUES(117,24,2);
INSERT INTO parking VALUES(118,24,3);
INSERT INTO parking VALUES(119,24,4);
INSERT INTO parking VALUES(120,24,5);
INSERT INTO parking VALUES(121,24,6);
INSERT INTO parking VALUES(122,24,7);
INSERT INTO parking VALUES(123,24,8);
INSERT INTO parking VALUES(124,25,1);
INSERT INTO parking VALUES(125,25,2);
INSERT INTO parking VALUES(126,26,1);
INSERT INTO parking VALUES(127,26,2);
INSERT INTO parking VALUES(128,26,3);
INSERT INTO parking VALUES(129,26,4);
INSERT INTO parking VALUES(130,26,5);
INSERT INTO parking VALUES(131,27,1);
INSERT INTO parking VALUES(132,27,2);
INSERT INTO parking VALUES(133,27,3);
INSERT INTO parking VALUES(134,27,4);
INSERT INTO parking VALUES(135,27,5);
INSERT INTO parking VALUES(136,28,1);
INSERT INTO parking VALUES(137,28,2);
INSERT INTO parking VALUES(138,28,3);
INSERT INTO parking VALUES(139,28,4);
INSERT INTO parking VALUES(140,28,5);
INSERT INTO parking VALUES(141,30,1);
INSERT INTO parking VALUES(142,30,2);
INSERT INTO parking VALUES(143,30,3);
INSERT INTO parking VALUES(144,30,4);
INSERT INTO parking VALUES(145,30,5);
INSERT INTO parking VALUES(146,30,6);
INSERT INTO parking VALUES(147,30,7);
INSERT INTO parking VALUES(148,30,8);
INSERT INTO parking VALUES(149,30,9);
INSERT INTO parking VALUES(150,30,10);
INSERT INTO parking VALUES(151,30,11);
INSERT INTO parking VALUES(152,30,12);
INSERT INTO parking VALUES(153,31,1);
INSERT INTO parking VALUES(154,31,2);
INSERT INTO parking VALUES(155,31,3);
INSERT INTO parking VALUES(156,32,1);
INSERT INTO parking VALUES(157,32,2);
INSERT INTO parking VALUES(158,32,3);
INSERT INTO parking VALUES(159,32,4);
INSERT INTO parking VALUES(160,32,5);
INSERT INTO parking VALUES(161,33,1);
INSERT INTO parking VALUES(162,33,2);
INSERT INTO parking VALUES(163,33,3);
INSERT INTO parking VALUES(164,33,4);
INSERT INTO parking VALUES(165,33,5);
INSERT INTO parking VALUES(166,34,1);
INSERT INTO parking VALUES(167,34,2);
INSERT INTO parking VALUES(168,34,3);
INSERT INTO parking VALUES(169,34,4);
INSERT INTO parking VALUES(170,34,5);
INSERT INTO parking VALUES(171,35,1);
INSERT INTO parking VALUES(172,35,2);
INSERT INTO parking VALUES(173,35,3);
INSERT INTO parking VALUES(174,35,4);
INSERT INTO parking VALUES(175,35,5);
INSERT INTO parking VALUES(176,36,1);
INSERT INTO parking VALUES(177,36,2);
INSERT INTO parking VALUES(178,36,3);
INSERT INTO parking VALUES(179,36,4);
INSERT INTO parking VALUES(180,36,5);
INSERT INTO parking VALUES(181,36,6);
INSERT INTO parking VALUES(182,36,7);
INSERT INTO parking VALUES(183,37,1);
INSERT INTO parking VALUES(184,37,2);
INSERT INTO parking VALUES(185,37,3);
INSERT INTO parking VALUES(186,37,4);
INSERT INTO parking VALUES(187,38,1);
INSERT INTO parking VALUES(188,38,2);
INSERT INTO parking VALUES(189,38,3);
INSERT INTO parking VALUES(190,38,4);

-- clients
INSERT INTO clients VALUES(1,'Piotr','Aktoriusz',1,1,'Ul.	Codzienna	3',1,'AAA 00000001');
INSERT INTO clients VALUES(2,'Jan','Fejsbuczak',1,1,'Ul.	Letnia	56',0,'AAA 00000002');
INSERT INTO clients VALUES(3,'Aldona','Cisowiak',1,1,'Ul.	Jesienna	8',0,'AAA 00000003');
INSERT INTO clients VALUES(4,'Ilona','Murowanka',1,2,'Ul.	Zimowa	3',0,'AAA 00000004');
INSERT INTO clients VALUES(5,'Jacek','Profiliusz',1,2,'Ul.	Zaporowa	4',1,'AAA 00000005');
INSERT INTO clients VALUES(6,'Lucjusz','Mafojczak',1,3,'Ul.	Ciemna	3',0,'AAA 00000006');
INSERT INTO clients VALUES(7,'Lidia','Jazowiak',1,3,'Ul.	Zimna	6',1,'AAA 00000007');
INSERT INTO clients VALUES(8,'Zuza','Oneciak',1,4,'Ul.	Zwierzyniecka	7',2,'AAA 00000008');
INSERT INTO clients VALUES(9,'Pola','Interiusz',1,5,'Ul.	Klonowa	45',0,'AAA 00000009');
INSERT INTO clients VALUES(10,'Cyprian','Kiepściuch',1,6,'Ul.	Kwiatowa	34',4,'AAA 00000010');
INSERT INTO clients VALUES(11,'Piotr','Komputerik',1,6,'Ul.	Pomarańczowa	6',3,'AAA 00000011');
INSERT INTO clients VALUES(12,'Maria','Elmecka',1,6,'Ul.	Zielona	43',0,'AAA 00000012');
INSERT INTO clients VALUES(13,'Dariusz','Drzewołaz',2,7,'Ul.	St Eve St	34',1,'AAA 00000013');
INSERT INTO clients VALUES(14,'Cecylia','Kobiecka',2,7,'Ul.	St John St	6',0,'AAA 00000014');
INSERT INTO clients VALUES(15,'Leopold','Banko',3,8,'Ul.	St Tomas St	3',1,'AAA 00000015');
INSERT INTO clients VALUES(16,'Zofia','Otwarty',3,8,'Ul.	St Lucas St	6',0,'AAA 00000016');
INSERT INTO clients VALUES(17,'Adam','Euforik',4,9,'Ul.	Podkopova	45',0,'AAA 00000017');
INSERT INTO clients VALUES(18,'Michał','Komórczak',5,10,'Ul.	Prekopova	6',0,'AAA 00000018');
INSERT INTO clients VALUES(19,'Mirosław','Ekspresik',6,11,'Ul.	Lukas Str.	34',1,'AAA 00000019');
INSERT INTO clients VALUES(20,'Dariusz','Googlarz',7,12,'Ul.	Rue De Rao	6',0,'AAA 00000020');
INSERT INTO clients VALUES(21,'Milena','Zgłoska',7,12,'Ul.	Rue Di Deo	45',1,'AAA 00000021');

-- reservations
INSERT INTO reservations VALUES(1,1,'2016-05-12','2016-05-13',3,NULL,1);
INSERT INTO reservations VALUES(2,2,'2016-05-14','2016-05-16',5,NULL,1);
INSERT INTO reservations VALUES(3,3,'2016-05-17','2016-05-20',8,NULL,1);
INSERT INTO reservations VALUES(4,4,'2016-05-21','2016-05-25',12,3,1);
INSERT INTO reservations VALUES(5,5,'2016-05-26','2016-05-31',17,NULL,0);
INSERT INTO reservations VALUES(6,6,'2016-06-01','2016-06-07',23,1,1);
INSERT INTO reservations VALUES(7,7,'2016-06-08','2016-06-15',30,1,0);
INSERT INTO reservations VALUES(8,8,'2016-06-16','2016-06-24',38,NULL,0);
INSERT INTO reservations VALUES(9,9,'2016-06-25','2016-07-04',47,1,0);
INSERT INTO reservations VALUES(10,10,'2016-07-05','2016-07-15',57,2,1);
INSERT INTO reservations VALUES(11,11,'2016-07-16','2016-07-27',68,2,1);
INSERT INTO reservations VALUES(12,12,'2016-07-28','2016-08-09',80,3,1);
INSERT INTO reservations VALUES(13,13,'2016-08-10','2016-08-23',93,1,0);
INSERT INTO reservations VALUES(14,14,'2016-08-24','2016-09-07',107,4,1);
INSERT INTO reservations VALUES(15,15,'2016-09-08','2016-09-23',122,1,1);
INSERT INTO reservations VALUES(16,16,'2016-09-24','2016-10-10',138,2,0);
INSERT INTO reservations VALUES(17,17,'2016-10-11','2016-10-28',155,3,0);
INSERT INTO reservations VALUES(18,18,'2016-10-29','2016-11-16',173,NULL,1);
INSERT INTO reservations VALUES(19,19,'2016-11-17','2016-12-06',190,NULL,0);
INSERT INTO reservations VALUES(20,20,'2016-12-07','2016-12-27',172,1,1);
INSERT INTO reservations VALUES(21,5,'2016-12-12','2016-12-17',167,1,0);
INSERT INTO reservations VALUES(22,7,'2016-12-19','2016-12-26',160,3,1);
INSERT INTO reservations VALUES(23,9,'2016-12-28','2017-01-06',151,1,1);
INSERT INTO reservations VALUES(24,1,'2016-12-29','2016-12-30',150,1,1);
INSERT INTO reservations VALUES(25,5,'2017-01-03','2017-01-08',145,NULL,1);
INSERT INTO reservations VALUES(26,3,'2017-01-06','2017-01-09',142,NULL,1);
INSERT INTO reservations VALUES(27,7,'2017-01-13','2017-01-20',135,1,1);
INSERT INTO reservations VALUES(28,2,'2017-01-15','2017-01-17',133,2,1);
INSERT INTO reservations VALUES(29,4,'2017-01-19','2017-01-23',129,NULL,1);
INSERT INTO reservations VALUES(30,6,'2017-01-25','2017-01-31',123,2,1);
INSERT INTO reservations VALUES(31,8,'2017-02-02','2017-02-10',115,2,1);
INSERT INTO reservations VALUES(32,9,'2017-02-11','2017-02-20',106,3,0);
INSERT INTO reservations VALUES(33,3,'2017-02-14','2017-02-17',103,NULL,1);
INSERT INTO reservations VALUES(34,2,'2017-02-16','2017-02-18',101,NULL,0);
INSERT INTO reservations VALUES(35,5,'2017-02-21','2017-02-26',96,1,1);
INSERT INTO reservations VALUES(36,12,'2017-03-05','2017-03-17',84,NULL,1);
INSERT INTO reservations VALUES(37,14,'2017-03-19','2017-04-02',70,1,1);
INSERT INTO reservations VALUES(38,17,'2017-04-05','2017-04-22',53,2,1);
INSERT INTO reservations VALUES(39,19,'2017-04-24','2017-05-13',34,2,1);
INSERT INTO reservations VALUES(40,3,'2017-04-27','2017-04-30',31,3,1);
INSERT INTO reservations VALUES(41,5,'2017-05-02','2017-05-07',26,1,0);
INSERT INTO reservations VALUES(42,9,'2017-05-11','2017-05-20',17,2,1);
INSERT INTO reservations VALUES(43,11,'2017-05-22','2017-06-02',6,NULL,0);
INSERT INTO reservations VALUES(44,10,'2017-06-01','2017-06-11',17,3,1);
INSERT INTO reservations VALUES(45,14,'2017-06-15','2017-06-29',27,1,0);
INSERT INTO reservations VALUES(46,15,'2017-06-30','2017-07-15',41,1,1);
INSERT INTO reservations VALUES(47,12,'2017-07-12','2017-07-24',56,2,1);
INSERT INTO reservations VALUES(48,1,'2017-07-13','2017-07-14',68,3,1);
INSERT INTO reservations VALUES(49,9,'2017-07-22','2017-07-31',69,4,1);
INSERT INTO reservations VALUES(50,3,'2017-07-25','2017-07-28',78,NULL,1);

